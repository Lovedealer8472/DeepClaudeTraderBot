"""
Scalper Entry Filters - Three-stage filter pipeline for high-quality scalper entries.

Stage 1: Microstructure Gate
Stage 2: Structure & Reversal Gate  
Stage 3: Candle Direction Prediction Gate
"""

from typing import Dict, Optional, Tuple, Any
from dataclasses import dataclass


@dataclass
class FilterResult:
    """Result of a filter stage."""
    passed: bool
    reason: Optional[str] = None
    details: Optional[Dict] = None


@dataclass
class StructureConfluence:
    """Structure confluence evaluation result."""
    count: int  # Number of aligned structure signals
    signals: list  # List of signal names present
    score_boost: float  # Additional score boost for confluence


def stage1_microstructure_gate(
    symbol: str,
    side: str,
    symbol_stats: Dict,
    orderbook: Optional[Dict],
    indicators: Optional[Dict],
    advanced_features: Optional[Any],
    entry_price: float
) -> FilterResult:
    """
    Stage 1: Microstructure Gate - MIGRATION PATCH
    
    SOFTENED: Rejects only if spread > 0.1% OR depth < 10-15k USD.
    Normal conditions are handled by scoring modules (score_liquidity, score_regime).
    Do not double-penalize conditions already covered by scoring.
    """
    details = {}
    
    # MIGRATION PATCH: Relaxed thresholds for balanced scalper mode
    # Normal spread/depth conditions are already handled by scoring modules
    spread_bps = symbol_stats.get('spread_bps', 9999)
    spread_pct = spread_bps / 10000.0
    details['spread_pct'] = spread_pct
    
    # Calculate depth if orderbook available
    depth_top_usd = 0.0
    if orderbook:
        bids = orderbook.get('bids', [])
        asks = orderbook.get('asks', [])
        if bids and asks:
            best_bid = bids[0][0] if bids else 0
            best_ask = asks[0][0] if asks else 0
            mid_price = (best_bid + best_ask) / 2.0 if (best_bid > 0 and best_ask > 0) else 0
            
            if mid_price > 0:
                # Depth within 10 bps (0.1%) of mid
                depth_window = mid_price * 0.001
                bid_depth = sum(
                    qty * price for price, qty in bids
                    if abs(best_bid - price) <= depth_window
                )
                ask_depth = sum(
                    qty * price for price, qty in asks
                    if abs(price - best_ask) <= depth_window
                )
                depth_top_usd = min(bid_depth, ask_depth)
    details['depth_top_usd'] = depth_top_usd
    
    # MIGRATION PATCH: Relaxed thresholds (spread <= 0.1%, depth >= 10k)
    # Reject only if spread > 0.1% OR (depth available AND depth < 10k USD)
    # If orderbook unavailable, skip depth check (depth handled by scoring modules)
    max_spread_pct = 0.001  # 0.1% (0.10%)
    min_depth_usd = 10000.0  # $10k USD
    
    # Check spread threshold
    spread_too_wide = spread_pct > max_spread_pct
    
    # Check depth only if orderbook is available
    # If orderbook is None/empty, depth_top_usd will be 0.0, but we skip the check
    depth_insufficient = False
    if orderbook and depth_top_usd > 0:
        # Only check depth if we actually have orderbook data
        depth_insufficient = depth_top_usd < min_depth_usd
    # If orderbook is missing, don't reject based on depth (scoring modules handle it)
    
    too_thin = spread_too_wide or depth_insufficient
    if too_thin:
        reason_detail = []
        if spread_too_wide:
            reason_detail.append(f"spread={spread_pct*100:.3f}% > {max_spread_pct*100:.2f}%")
        if depth_insufficient:
            reason_detail.append(f"depth=${depth_top_usd:.0f} < ${min_depth_usd:.0f}")
        return FilterResult(
            passed=False,
            reason=f"microstructure_fail: {' and '.join(reason_detail)}",
            details={"spread_pct": spread_pct, "depth_top_usd": depth_top_usd, "threshold_spread": max_spread_pct, "threshold_depth": min_depth_usd}
        )
    
    # PURE_SCALPER: Remove bid/ask imbalance and VWAP distance checks
    # These are already handled by scoring modules (score_liquidity, score_regime, score_structure)
    # Do not double-penalize conditions already covered by scoring
    
    return FilterResult(passed=True, reason="microstructure_pass", details=details)


def stage2_structure_gate(
    side: str,
    advanced_features: Optional[Any],
    indicators: Optional[Dict],
    symbol_stats: Dict
) -> Tuple[FilterResult, StructureConfluence]:
    """
    Stage 2: Structure & Reversal Gate - BALANCED MODE
    
    Requires: (1 strong signal) OR (2 medium signals)
    
    Strong signals:
    - Exhaustion (exhaustion_up/down)
    - Divergence (bullish/bearish)
    - SFP (swing failure pattern top/bottom)
    
    Medium signals:
    - VWAP recoil
    - Range position (at_range_low/high)
    """
    signals_present = []
    count = 0
    
    if not advanced_features:
        return (
            FilterResult(passed=False, reason="structure_fail: no_advanced_features"),
            StructureConfluence(count=0, signals=[], score_boost=0.0)
        )
    
    # Check exhaustion
    if side == "long":
        if hasattr(advanced_features, 'exhaustion_down') and advanced_features.exhaustion_down:
            signals_present.append("exhaustion_down")
            count += 1
    else:
        if hasattr(advanced_features, 'exhaustion_up') and advanced_features.exhaustion_up:
            signals_present.append("exhaustion_up")
            count += 1
    
    # Check divergence
    if side == "long":
        if hasattr(advanced_features, 'bullish_divergence') and advanced_features.bullish_divergence:
            signals_present.append("bullish_divergence")
            count += 1
    else:
        if hasattr(advanced_features, 'bearish_divergence') and advanced_features.bearish_divergence:
            signals_present.append("bearish_divergence")
            count += 1
    
    # Check SFP
    if side == "long":
        if hasattr(advanced_features, 'sfp_bottom') and advanced_features.sfp_bottom:
            signals_present.append("sfp_bottom")
            count += 1
    else:
        if hasattr(advanced_features, 'sfp_top') and advanced_features.sfp_top:
            signals_present.append("sfp_top")
            count += 1
    
    # Check VWAP recoil (price snapping back toward VWAP in trade direction)
    if hasattr(advanced_features, 'dist_from_vwap'):
        dist = advanced_features.dist_from_vwap
        if side == "long" and dist < -0.01:  # Price below VWAP, snapping back up
            signals_present.append("vwap_recoil")
            count += 1
        elif side == "short" and dist > 0.01:  # Price above VWAP, snapping back down
            signals_present.append("vwap_recoil")
            count += 1
    
    # Check range position (at range low/high)
    if side == "long":
        if hasattr(advanced_features, 'at_range_low') and advanced_features.at_range_low:
            signals_present.append("range_low")
            count += 1
    else:
        if hasattr(advanced_features, 'at_range_high') and advanced_features.at_range_high:
            signals_present.append("range_high")
            count += 1
    
    # BALANCED MODE: Require (1 strong) OR (2 medium) signals
    # Strong signals: exhaustion, divergence, SFP
    # Medium signals: VWAP recoil, range position
    strong_signals = [s for s in signals_present if s in ['exhaustion_down', 'exhaustion_up', 
                                                           'bullish_divergence', 'bearish_divergence',
                                                           'sfp_bottom', 'sfp_top']]
    medium_signals = [s for s in signals_present if s in ['vwap_recoil', 'range_low', 'range_high']]
    
    # Pass if: (1+ strong) OR (2+ medium) OR (1 strong + 1 medium)
    passed = (len(strong_signals) >= 1) or (len(medium_signals) >= 2) or (len(strong_signals) >= 1 and len(medium_signals) >= 1)
    
    # Calculate score boost based on confluence - BALANCED MODE: Boost for 1 strong signal
    if count >= 3:
        score_boost = 8.0  # Strong confluence
    elif len(strong_signals) >= 2:
        score_boost = 6.0  # Two strong signals
    elif len(strong_signals) >= 1:
        score_boost = 4.0  # One strong signal (BALANCED MODE: allow with boost)
    elif count >= 2:
        score_boost = 3.0  # Two medium signals
    else:
        score_boost = 0.0
    
    confluence = StructureConfluence(
        count=count,
        signals=signals_present,
        score_boost=score_boost
    )
    
    if not passed:
        return (
            FilterResult(
                passed=False,
                reason=f"structure_fail: insufficient_confluence (strong={len(strong_signals)}, medium={len(medium_signals)})",
                details={"signals": signals_present, "count": count, "strong": strong_signals, "medium": medium_signals}
            ),
            confluence
        )
    
    return (
        FilterResult(
            passed=True,
            reason="structure_pass",
            details={"signals": signals_present, "count": count}
        ),
        confluence
    )


def stage3_direction_prediction(
    side: str,
    indicators: Optional[Dict],
    advanced_features: Optional[Any],
    symbol_stats: Dict,
    orderbook: Optional[Dict],
    entry_price: float
) -> FilterResult:
    """
    Stage 3: Candle Direction Prediction Gate - BALANCED MODE
    
    Estimates probability that next 1-3 candles move in desired direction.
    Returns direction_score 0-1 where:
    - ~0.5 = neutral
    - >=0.56 = reasonably strong directional bias (was >=0.58-0.60)
    
    For longs: require direction_score >= 0.56 (BALANCED MODE, was 0.58-0.60)
    For shorts: require equivalent bias in opposite direction
    """
    direction_score = 0.5  # Start neutral
    
    if not indicators:
        return FilterResult(
            passed=False,
            reason="direction_fail: no_indicators",
            details={"direction_score": direction_score}
        )
    
    # Extract features
    atr_pct = indicators.get('atr_pct', 0.01)
    rsi = indicators.get('rsi', 50.0)
    adx = indicators.get('adx', 20.0)
    
    # VWAP distance
    dist_from_vwap = 0.0
    if advanced_features and hasattr(advanced_features, 'dist_from_vwap'):
        dist_from_vwap = advanced_features.dist_from_vwap
    
    # Exhaustion flags
    has_exhaustion = False
    if advanced_features:
        if side == "long":
            has_exhaustion = (advanced_features.exhaustion_down if hasattr(advanced_features, 'exhaustion_down') else False)
        else:
            has_exhaustion = (advanced_features.exhaustion_up if hasattr(advanced_features, 'exhaustion_up') else False)
    
    # Divergence flags
    has_divergence = False
    if advanced_features:
        if side == "long":
            has_divergence = (advanced_features.bullish_divergence if hasattr(advanced_features, 'bullish_divergence') else False)
        else:
            has_divergence = (advanced_features.bearish_divergence if hasattr(advanced_features, 'bearish_divergence') else False)
    
    # HTF trend direction
    htf_trend_dir = 0
    if advanced_features and hasattr(advanced_features, 'htf_trend_dir'):
        htf_trend_dir = advanced_features.htf_trend_dir
    
    # Range position
    at_range_extreme = False
    if advanced_features:
        if side == "long":
            at_range_extreme = (advanced_features.at_range_low if hasattr(advanced_features, 'at_range_low') else False)
        else:
            at_range_extreme = (advanced_features.at_range_high if hasattr(advanced_features, 'at_range_high') else False)
    
    # Microstructure (spread)
    spread_bps = symbol_stats.get('spread_bps', 9999)
    spread_quality = 1.0 - min(spread_bps / 100.0, 1.0)  # 0-1, better spread = higher
    
    # Build direction_score from components
    # Base: RSI position
    if side == "long":
        rsi_bias = (rsi - 30.0) / 40.0  # RSI 30-70 range -> 0-1
        rsi_bias = max(0.0, min(1.0, rsi_bias))
        direction_score = 0.4 + (rsi_bias * 0.2)  # 0.4-0.6 base
    else:  # short
        rsi_bias = (70.0 - rsi) / 40.0  # RSI 70-30 range -> 0-1
        rsi_bias = max(0.0, min(1.0, rsi_bias))
        direction_score = 0.4 + (rsi_bias * 0.2)  # 0.4-0.6 base
    
    # VWAP distance adjustment
    if side == "long":
        if dist_from_vwap < -0.01:  # Below VWAP, good for long
            direction_score += 0.05
        elif dist_from_vwap > 0.01:  # Above VWAP, bad for long
            direction_score -= 0.05
    else:  # short
        if dist_from_vwap > 0.01:  # Above VWAP, good for short
            direction_score += 0.05
        elif dist_from_vwap < -0.01:  # Below VWAP, bad for short
            direction_score -= 0.05
    
    # Exhaustion boost
    if has_exhaustion:
        direction_score += 0.08
    
    # Divergence boost
    if has_divergence:
        direction_score += 0.06
    
    # HTF trend alignment
    if side == "long" and htf_trend_dir > 0:
        direction_score += 0.04
    elif side == "short" and htf_trend_dir < 0:
        direction_score += 0.04
    
    # Range extreme boost
    if at_range_extreme:
        direction_score += 0.04
    
    # ADX adjustment (volatility context)
    if adx > 25:  # Strong trend
        direction_score += 0.03
    elif adx < 15:  # Weak trend/chop
        direction_score -= 0.03
    
    # Spread quality adjustment
    direction_score += (spread_quality - 0.5) * 0.02
    
    # Clamp to 0-1
    direction_score = max(0.0, min(1.0, direction_score))
    
    # Threshold check - LIVE MODE: Lowered to 0.55 for more signals (was 0.56, originally 0.58-0.60)
    min_direction_score = 0.55 if side == "long" else 0.55  # Same threshold for both
    
    if direction_score < min_direction_score:
        return FilterResult(
            passed=False,
            reason=f"direction_fail: score_too_low ({direction_score:.3f} < {min_direction_score})",
            details={"direction_score": direction_score, "min_required": min_direction_score}
        )
    
    return FilterResult(
        passed=True,
        reason="direction_pass",
        details={"direction_score": direction_score}
    )


def evaluate_three_stage_filter(
    symbol: str,
    side: str,
    symbol_stats: Dict,
    orderbook: Optional[Dict],
    indicators: Optional[Dict],
    advanced_features: Optional[Any],
    entry_price: float,
    final_score: Optional[float] = None  # SCORING V2 final score for debug logging
) -> Tuple[bool, Optional[str], Optional[Dict], Optional[StructureConfluence]]:
    """
    Evaluate all three filter stages.
    
    Returns:
        (passed, rejection_reason, filter_details, structure_confluence)
    """
    # Stage 1: Microstructure
    stage1_result = stage1_microstructure_gate(
        symbol, side, symbol_stats, orderbook, indicators, advanced_features, entry_price
    )
    if not stage1_result.passed:
        return False, stage1_result.reason, stage1_result.details, None
    
    # Stage 2: Structure
    stage2_result, confluence = stage2_structure_gate(
        side, advanced_features, indicators, symbol_stats
    )
    if not stage2_result.passed:
        # DEBUG: Print when Stage 1 passes but Stage 2 fails
        print(f"[DEBUG FILTER] {symbol} | stage_passed=stage1 | final_score={final_score or 'N/A'}")
        return False, stage2_result.reason, stage2_result.details, confluence
    
    # DEBUG: Print when both Stage 1 and Stage 2 pass
    print(f"[DEBUG FILTER] {symbol} | stage_passed=stage1+stage2 | final_score={final_score or 'N/A'}")
    
    # Stage 3: Direction
    stage3_result = stage3_direction_prediction(
        side, indicators, advanced_features, symbol_stats, orderbook, entry_price
    )
    if not stage3_result.passed:
        return False, stage3_result.reason, stage3_result.details, confluence
    
    # All stages passed
    filter_details = {
        "stage1": stage1_result.details,
        "stage2": stage2_result.details,
        "stage3": stage3_result.details
    }
    
    return True, None, filter_details, confluence

