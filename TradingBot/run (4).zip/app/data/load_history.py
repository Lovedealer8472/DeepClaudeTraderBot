"""
Load Historical OHLCV Data - Helper to load candles from exchange or CSV.

Supports loading from:
1. CSV files: data/history/{symbol}_{timeframe}.csv
2. Exchange API: ccxt.fetch_ohlcv() in chunks
"""

import os
import csv
from typing import Dict, List, Optional
import ccxt
from datetime import datetime, timedelta


def load_history_from_csv(symbol: str, timeframe: str, data_dir: str = "data/history") -> Optional[List[List]]:
    """
    Load OHLCV candles from CSV file.
    
    CSV format: timestamp_ms,open,high,low,close,volume (one row per candle)
    
    Args:
        symbol: Trading symbol (e.g., "BTC/USDT:USDT")
        timeframe: Timeframe (e.g., "1m", "5m")
        data_dir: Directory containing CSV files
        
    Returns:
        List of [timestamp_ms, open, high, low, close, volume] or None if file not found
    """
    # Normalize symbol for filename (replace / and : with _)
    safe_symbol = symbol.replace("/", "_").replace(":", "_")
    filename = os.path.join(data_dir, f"{safe_symbol}_{timeframe}.csv")
    
    if not os.path.exists(filename):
        return None
    
    candles = []
    try:
        with open(filename, 'r') as f:
            reader = csv.reader(f)
            for row in reader:
                if len(row) < 5:
                    continue
                try:
                    ts = int(row[0])
                    open_price = float(row[1])
                    high = float(row[2])
                    low = float(row[3])
                    close = float(row[4])
                    volume = float(row[5]) if len(row) > 5 else 0.0
                    candles.append([ts, open_price, high, low, close, volume])
                except (ValueError, IndexError):
                    continue
    except Exception as e:
        print(f"Error reading CSV {filename}: {e}")
        return None
    
    return candles if candles else None


def load_history_from_exchange(
    exchange: ccxt.Exchange,
    symbol: str,
    timeframe: str,
    start_ts: int,
    end_ts: int,
    limit: int = 1000
) -> List[List]:
    """
    Load OHLCV candles from exchange API.
    
    Args:
        exchange: ccxt exchange instance
        symbol: Trading symbol
        timeframe: Timeframe (e.g., "1m", "5m")
        start_ts: Start timestamp (Unix seconds)
        end_ts: End timestamp (Unix seconds)
        limit: Max candles per request
        
    Returns:
        List of [timestamp_ms, open, high, low, close, volume]
    """
    all_candles = []
    current_ts = start_ts
    
    # Convert to milliseconds for ccxt
    start_ms = start_ts * 1000
    end_ms = end_ts * 1000
    
    # Calculate timeframe duration in milliseconds
    timeframe_durations = {
        '1m': 60 * 1000,
        '5m': 5 * 60 * 1000,
        '15m': 15 * 60 * 1000,
        '1h': 60 * 60 * 1000,
        '4h': 4 * 60 * 60 * 1000,
        '1d': 24 * 60 * 60 * 1000,
    }
    duration_ms = timeframe_durations.get(timeframe, 60 * 1000)
    
    # Fetch in chunks
    while current_ts * 1000 < end_ms:
        try:
            # Fetch candles
            since_ms = current_ts * 1000
            candles = exchange.fetch_ohlcv(symbol, timeframe, since=since_ms, limit=limit)
            
            if not candles:
                break
            
            # Filter candles within time range
            for candle in candles:
                ts_ms = candle[0]
                if start_ms <= ts_ms <= end_ms:
                    all_candles.append(candle)
            
            # Move to next chunk
            if len(candles) < limit:
                break
            
            last_ts_ms = candles[-1][0]
            current_ts = (last_ts_ms + duration_ms) / 1000.0
            
            # Avoid infinite loop
            if current_ts * 1000 >= end_ms:
                break
                
        except Exception as e:
            print(f"Error fetching candles from exchange for {symbol}: {e}")
            break
    
    # Sort by timestamp and remove duplicates
    all_candles.sort(key=lambda x: x[0])
    seen = set()
    unique_candles = []
    for candle in all_candles:
        if candle[0] not in seen:
            seen.add(candle[0])
            unique_candles.append(candle)
    
    return unique_candles


def load_history(
    symbols: List[str],
    timeframe: str,
    start_ts: int,
    end_ts: int,
    exchange: Optional[ccxt.Exchange] = None,
    data_dir: str = "data/history"
) -> Dict[str, List[List]]:
    """
    Load historical OHLCV candles for multiple symbols.
    
    Tries CSV first, falls back to exchange API if CSV not found.
    
    Args:
        symbols: List of trading symbols
        timeframe: Timeframe (e.g., "1m", "5m")
        start_ts: Start timestamp (Unix seconds)
        end_ts: End timestamp (Unix seconds)
        exchange: Optional ccxt exchange instance (for API fallback)
        data_dir: Directory for CSV files
        
    Returns:
        Dict mapping symbol -> list of [timestamp_ms, open, high, low, close, volume]
    """
    candles_by_symbol = {}
    
    for symbol in symbols:
        # Try CSV first
        candles = load_history_from_csv(symbol, timeframe, data_dir)
        
        # If CSV not found and exchange provided, fetch from API
        if candles is None and exchange:
            print(f"CSV not found for {symbol}, fetching from exchange...")
            candles = load_history_from_exchange(exchange, symbol, timeframe, start_ts, end_ts)
            
            # Optionally save to CSV for future use
            if candles and data_dir:
                os.makedirs(data_dir, exist_ok=True)
                safe_symbol = symbol.replace("/", "_").replace(":", "_")
                filename = os.path.join(data_dir, f"{safe_symbol}_{timeframe}.csv")
                try:
                    with open(filename, 'w', newline='') as f:
                        writer = csv.writer(f)
                        for candle in candles:
                            writer.writerow(candle)
                    print(f"Saved {len(candles)} candles to {filename}")
                except Exception as e:
                    print(f"Error saving CSV {filename}: {e}")
        
        if candles:
            # Filter candles within time range
            start_ms = start_ts * 1000
            end_ms = end_ts * 1000
            filtered = [c for c in candles if start_ms <= c[0] <= end_ms]
            if filtered:
                candles_by_symbol[symbol] = filtered
                print(f"Loaded {len(filtered)} candles for {symbol}")
            else:
                print(f"No candles in time range for {symbol}")
        else:
            print(f"No candles loaded for {symbol}")
    
    return candles_by_symbol

