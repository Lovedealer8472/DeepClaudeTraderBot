"""
Replay Data Feed - Provides historical OHLCV data for backtesting.

Mimics the live exchange data interface so the bot can run in replay mode
without modification to strategy logic.
"""

from typing import Dict, List, Optional, Tuple
from dataclasses import dataclass
import time


@dataclass
class OHLCVCandle:
    """Single OHLCV candle."""
    timestamp: int  # Unix timestamp in milliseconds
    open: float
    high: float
    low: float
    close: float
    volume: float


class ReplayDataFeed:
    """
    Replay data feed that provides historical OHLCV candles.
    
    Maintains an index per symbol and provides current price/OHLCV
    that mimics the live exchange interface.
    """
    
    def __init__(self, candles_by_symbol: Dict[str, List[List]], synthetic_spread_pct: float = 0.0005, synthetic_depth_qty: float = 15000.0):
        """
        Initialize replay feed with historical candles.
        
        Args:
            candles_by_symbol: Dict mapping symbol -> list of [ts, open, high, low, close, volume]
                              Each candle is a list: [timestamp_ms, open, high, low, close, volume]
            synthetic_spread_pct: Synthetic spread percentage (default 0.05% = 0.0005)
            synthetic_depth_qty: Synthetic orderbook depth quantity (default 15000)
        """
        self.candles_by_symbol: Dict[str, List[OHLCVCandle]] = {}
        self.indices: Dict[str, int] = {}  # Current index per symbol
        self.current_time: float = 0.0  # Current replay time (Unix timestamp)
        self.synthetic_spread_pct = synthetic_spread_pct  # 0.05% default
        self.synthetic_depth_qty = synthetic_depth_qty  # 15000 default (as per user spec)
        
        # Convert raw candles to OHLCVCandle objects and initialize indices
        for symbol, candles in candles_by_symbol.items():
            if not candles:
                continue
            
            self.candles_by_symbol[symbol] = [
                OHLCVCandle(
                    timestamp=candle[0],
                    open=float(candle[1]),
                    high=float(candle[2]),
                    low=float(candle[3]),
                    close=float(candle[4]),
                    volume=float(candle[5]) if len(candle) > 5 else 0.0
                )
                for candle in candles
            ]
            self.indices[symbol] = 0
            
            # Set initial current_time from first candle
            if self.current_time == 0.0 and self.candles_by_symbol[symbol]:
                self.current_time = self.candles_by_symbol[symbol][0].timestamp / 1000.0
    
    def step(self) -> bool:
        """
        Advance all symbols to the next candle.
        
        Returns:
            True if any symbol advanced, False if all are at the end
        """
        any_advanced = False
        min_next_time = None
        
        # Find the minimum next timestamp across all symbols
        for symbol in self.candles_by_symbol.keys():
            idx = self.indices.get(symbol, 0)
            candles = self.candles_by_symbol.get(symbol, [])
            if idx + 1 < len(candles):
                next_candle = candles[idx + 1]
                if min_next_time is None or next_candle.timestamp < min_next_time:
                    min_next_time = next_candle.timestamp
        
        if min_next_time is None:
            return False  # All symbols at end
        
        # Advance all symbols that have a candle at or before min_next_time
        for symbol in self.candles_by_symbol.keys():
            idx = self.indices.get(symbol, 0)
            candles = self.candles_by_symbol.get(symbol, [])
            if idx + 1 < len(candles):
                next_candle = candles[idx + 1]
                if next_candle.timestamp <= min_next_time:
                    self.indices[symbol] = idx + 1
                    any_advanced = True
        
        # Update current time
        if min_next_time is not None:
            self.current_time = min_next_time / 1000.0
        
        return any_advanced
    
    def get_current_candle(self, symbol: str) -> Optional[OHLCVCandle]:
        """Get current candle for a symbol."""
        candles = self.candles_by_symbol.get(symbol)
        if not candles:
            return None
        idx = self.indices.get(symbol, 0)
        if idx >= len(candles):
            return candles[-1] if candles else None
        return candles[idx]
    
    def get_current_price(self, symbol: str) -> Optional[float]:
        """
        Get current price (close price of current candle).
        Mimics exchange mark price / last price.
        """
        candle = self.get_current_candle(symbol)
        if candle:
            return candle.close
        return None
    
    def get_ticker_data(self, symbol: str) -> Optional[Dict]:
        """
        Get ticker-like data for a symbol with synthetic market data.
        Mimics exchange fetch_ticker() response exactly.
        
        Uses synthetic spread (0.05% default) around close price.
        Structure matches what live exchange returns.
        """
        candle = self.get_current_candle(symbol)
        if not candle:
            return None
        
        # Synthetic market data based on current candle close price
        close = candle.close
        last_price = close
        mark_price = close
        
        # Create tiny synthetic spread: 0.05% (0.0005)
        best_bid = close * 0.9995  # 0.05% below
        best_ask = close * 1.0005  # 0.05% above
        spread = best_ask - best_bid
        
        # Synthetic depth (placeholders)
        bid_qty = self.synthetic_depth_qty  # 15000 default
        ask_qty = self.synthetic_depth_qty  # 15000 default
        
        # Return structure matching live exchange ticker format
        return {
            'symbol': symbol,
            'bid': best_bid,
            'ask': best_ask,
            'last': last_price,
            'mark': mark_price,
            'info': {
                'fairPx': mark_price,
                'markPrice': mark_price,
            },
            'quoteVolume': candle.volume,
            'percentage': 0.0,  # 24h change not available in replay
            'bid_qty': bid_qty,
            'ask_qty': ask_qty,
        }
    
    def get_market_snapshot(self, symbol: str) -> Optional[Dict]:
        """
        Get market snapshot with orderbook data for a symbol.
        MIGRATION PATCH: Enhanced with 3-level synthetic orderbook.
        Mimics exchange market snapshot response exactly.
        
        Returns:
            Dict with ticker data and 3-level orderbook structure matching live mode
        """
        ticker = self.get_ticker_data(symbol)
        if not ticker:
            return None
        
        # MIGRATION PATCH: Build 3-level synthetic orderbook with proper depth calculation
        close = ticker['last']
        bid_qty_base = self.synthetic_depth_qty  # 15000 default
        ask_qty_base = self.synthetic_depth_qty  # 15000 default
        
        # Create 3-level orderbook: each level has 5000 quantity (total 15000 per side)
        # Bids: below best_bid, decreasing price
        # Asks: above best_ask, increasing price
        bids = []
        asks = []
        price_step = close * 0.0001  # 0.01% step between levels
        
        for i in range(3):
            # Bids: best_bid - i*step, quantity 5000
            # Formula: close*0.9995 - i*close*0.0001
            bid_price = ticker['bid'] - i * price_step
            bids.append([bid_price, 5000.0])
            
            # Asks: best_ask + i*step, quantity 5000
            # Formula: close*1.0005 + i*close*0.0001
            ask_price = ticker['ask'] + i * price_step
            asks.append([ask_price, 5000.0])
        
        # Ensure depth calculation will work: total depth = 15000 USD per side
        # Each level contributes 5000 * price, so total depth_top_usd should be ~15000
        
        # Orderbook structure: [[price, quantity], ...] with 3 levels
        orderbook = {
            'bids': bids,
            'asks': asks,
        }
        
        return {
            'symbol': symbol,
            'ticker': ticker,
            'orderbook': orderbook,
            'last_price': ticker['last'],
            'mark_price': ticker['mark'],
            'best_bid': ticker['bid'],
            'best_ask': ticker['ask'],
            'spread': ticker['ask'] - ticker['bid'],
            'bid_qty': bid_qty_base,
            'ask_qty': ask_qty_base,
        }
    
    def get_price(self, symbol: str) -> Optional[float]:
        """
        Get current price for a symbol (alias for get_current_price).
        """
        return self.get_current_price(symbol)
    
    def get_ohlcv(self, symbol: str, timeframe: str = "1m", limit: int = 100) -> List[List]:
        """
        Get OHLCV candles for a symbol.
        Mimics exchange fetch_ohlcv() response.
        
        Returns candles up to current index.
        """
        candles = self.candles_by_symbol.get(symbol, [])
        if not candles:
            return []
        
        idx = self.indices.get(symbol, 0)
        # Return candles from start up to current index (or limit)
        end_idx = min(idx + 1, len(candles))
        start_idx = max(0, end_idx - limit)
        
        result = []
        for i in range(start_idx, end_idx):
            c = candles[i]
            result.append([
                c.timestamp,  # ts
                c.open,       # open
                c.high,       # high
                c.low,        # low
                c.close,      # close
                c.volume      # volume
            ])
        
        return result
    
    def get_current_time(self) -> float:
        """Get current replay time as Unix timestamp."""
        return self.current_time
    
    def is_finished(self) -> bool:
        """Check if all symbols have reached the end."""
        for symbol in self.candles_by_symbol.keys():
            idx = self.indices.get(symbol, 0)
            candles = self.candles_by_symbol.get(symbol, [])
            if idx + 1 < len(candles):
                return False
        return True
    
    def get_total_steps(self) -> int:
        """Get total number of candles (max across all symbols)."""
        max_len = 0
        for candles in self.candles_by_symbol.values():
            max_len = max(max_len, len(candles))
        return max_len

