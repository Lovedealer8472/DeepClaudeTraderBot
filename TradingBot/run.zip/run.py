"""
Trading bot entry point.

CRITICAL: NO console output when UI v2 is active.
All logs/errors go to file logger.
"""

import asyncio
import sys
import signal
import os

# Fix Windows console encoding for Unicode/emoji characters
if os.name == 'nt':
    try:
        import io
        sys.stdout = io.TextIOWrapper(sys.stdout.buffer, encoding='utf-8', errors='replace')
        sys.stderr = io.TextIOWrapper(sys.stderr.buffer, encoding='utf-8', errors='replace')
    except Exception:
        pass  # Fallback if encoding can't be changed

# Load .env file if it exists
try:
    from dotenv import load_dotenv
    load_dotenv()
except ImportError:
    pass  # dotenv is optional

from app.bot import ScalperBot
from app.config_validator import validate_and_exit_on_error
from app.logger import get_logger


async def main():
    """
    Main entry point for the trading bot.
    All output goes to file logger, NOT console (to preserve UI).
    """
    # STARTUP DIAGNOSTICS (console output OK before UI starts)
    print("[STARTUP] Validating configuration...")
    try:
        validate_and_exit_on_error()
        print("[STARTUP] ✓ Configuration validated")
    except Exception as e:
        print(f"[STARTUP] ✗ Configuration validation failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    # Get logger
    print("[STARTUP] Initializing logger...")
    try:
        logger = get_logger("TradingBot")
        print("[STARTUP] ✓ Logger initialized")
    except Exception as e:
        print(f"[STARTUP] ✗ Logger initialization failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    logger.info("="*80)
    logger.info("TRADING BOT STARTING")
    logger.info("="*80)
    
    print("[STARTUP] Creating bot instance...")
    print("[STARTUP] UI will take over in 3 seconds...")
    print("[STARTUP] If bot crashes, check logs/bot_*.log for details")
    
    try:
        bot = ScalperBot()
        print("[STARTUP] ✓ Bot instance created")
    except Exception as e:
        print(f"[STARTUP] ✗ Bot instance creation failed: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)
    
    original_stdout = sys.stdout
    original_stderr = sys.stderr
    
    try:
        print("[STARTUP] Starting bot.run()...")
        await bot.run()
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Restore stdout/stderr for safe logging
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        
        logger.info("="*80)
        logger.info("BOT SHUTDOWN")
        logger.info("="*80)
        logger.info("Manual shutdown requested (Ctrl+C)")
        logger.info("Saving state and closing connections...")
        
        # Save state
        try:
            if hasattr(bot, 'fast_storage'):
                bot.fast_storage.close()
            logger.info("✓ State saved")
        except Exception as e:
            logger.error(f"⚠ State save failed: {e}")
        
        # Close exchange
        try:
            if bot.exchange_wrapper:
                await bot.exchange_wrapper.close()
            elif bot.exchange:
                await bot.exchange.close()
            logger.info("✓ Exchange connection closed")
        except Exception as e:
            logger.error(f"Exchange close failed: {e}")
        
        logger.info("Bot shutdown complete.")
        logger.info("="*80)
        sys.exit(0)
        
    except Exception as e:
        # Restore stdout/stderr for safe logging
        sys.stdout = original_stdout
        sys.stderr = original_stderr
        
        # Log exception to file with full traceback
        logger.critical(f"FATAL ERROR: {type(e).__name__}: {e}")
        logger.exception("Full traceback:")
        
        # DO NOT print to console - only log to file
        sys.exit(1)


if __name__ == "__main__":
    try:
        asyncio.run(main())
    except (KeyboardInterrupt, asyncio.CancelledError):
        # Final fallback - log to file if possible
        try:
            logger = get_logger("TradingBot")
            logger.info("[SHUTDOWN] Bot stopped by user")
        except Exception:
            pass  # Silently exit
        sys.exit(0)
    except Exception as e:
        # Final fallback - log to file if possible
        try:
            logger = get_logger("TradingBot")
            logger.critical(f"[FATAL] Unhandled exception: {e}")
            logger.exception("Full traceback:")
        except Exception:
            pass  # Silently exit
        sys.exit(1)
