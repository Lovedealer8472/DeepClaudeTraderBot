"""
Structured logging infrastructure for the trading bot.
Provides consistent logging with levels, context, and file output.

CRITICAL: When UI v2 is active, NO console output is allowed.
All logs go to file + in-memory buffer for UI display.
"""

import logging
import os
import sys
from datetime import datetime
from pathlib import Path
from typing import Optional, Dict, Any, List
from logging.handlers import RotatingFileHandler
from collections import deque
from threading import Lock


class InMemoryLogBuffer:
    """
    Thread-safe in-memory log buffer for UI display.
    Stores recent log messages that can be shown in the UI log panel.
    """
    
    def __init__(self, maxlen: int = 50):
        """
        Initialize log buffer.
        
        Args:
            maxlen: Maximum number of log entries to keep
        """
        self._buffer = deque(maxlen=maxlen)
        self._lock = Lock()
    
    def append(self, timestamp: datetime, level: str, message: str):
        """
        Add log entry to buffer.
        
        Args:
            timestamp: Log timestamp
            level: Log level (DEBUG, INFO, WARNING, ERROR, CRITICAL)
            message: Log message
        """
        with self._lock:
            self._buffer.append({
                'timestamp': timestamp,
                'level': level,
                'message': message
            })
    
    def get_recent(self, limit: int = 50) -> List[Dict[str, Any]]:
        """
        Get recent log entries.
        
        Args:
            limit: Maximum number of entries to return
            
        Returns:
            List of log entries (newest first)
        """
        with self._lock:
            # Return a copy to prevent concurrent modification
            entries = list(self._buffer)
            return entries[-limit:] if entries else []
    
    def clear(self):
        """Clear all log entries."""
        with self._lock:
            self._buffer.clear()


class UILogHandler(logging.Handler):
    """
    Custom logging handler that filters and routes ONLY high-signal messages to UI LOG panel.
    
    Only shows:
    - Loop summaries (contains "SIG=" or "SIG:")
    - Risk warnings (max positions, correlation, drawdown)
    - System warnings/errors (API timeouts, exchange errors)
    - Major regime/mode changes (BTC trend, volatility, strategy)
    
    Excludes:
    - DEBUG messages (always)
    - Per-signal "Unicorn check" spam
    - Per-signal "SIGNAL GENERATED" spam
    - PRS debug per position
    - Any messages that fire dozens of times per minute
    """
    
    # Patterns that should appear in LOG panel
    APPROVED_PATTERNS = [
        r'SIG[=:]',  # Loop summaries (SIG=3 or SIG:3)
        r'max positions|position limit|positions reached',
        r'correlation.*block|RJ.*correlation',
        r'drawdown.*threshold|circuit breaker',
        r'API.*timeout|API.*retry|exchange.*error|exchange.*outage',
        r'BTC.*trend.*flip|BTC.*trend.*UP|BTC.*trend.*DOWN',
        r'volatility.*regime|VOLATILITY.*LOW|VOLATILITY.*HIGH',
        r'strategy.*switch|mode.*switch|DRY.*LIVE|LIVE.*DRY',
        r'STARTUP|SHUTDOWN',
        r'FATAL|CRITICAL',
        r'ERROR.*Exit failed',  # Exit failures (important)
    ]
    
    # Patterns that should be EXCLUDED from LOG panel (even if INFO/WARNING)
    EXCLUDED_PATTERNS = [
        r'Unicorn check',
        r'SIGNAL GENERATED',
        r'score.*dump|final_score.*=',
        r'PRS.*debug|\[PRS\].*position',
        r'Symbol.*processed|symbol.*scanned',
        r'Signal.*confirmed.*ready',  # Too frequent
        r'Signal.*waiting.*confirmation',  # Too frequent
        r'Signal.*blocked.*position_manager',  # Too frequent
        r'Signal.*REJECTED.*generator',  # Too frequent
        r'⚠️ NO STATS',  # Debug only
    ]
    
    def __init__(self, buffer: InMemoryLogBuffer):
        """
        Initialize UI log handler.
        
        Args:
            buffer: InMemoryLogBuffer instance
        """
        super().__init__()
        self.buffer = buffer
        import re
        self.approved_regex = [re.compile(pattern, re.IGNORECASE) for pattern in self.APPROVED_PATTERNS]
        self.excluded_regex = [re.compile(pattern, re.IGNORECASE) for pattern in self.EXCLUDED_PATTERNS]
        self.setLevel(logging.INFO)  # Only INFO/WARNING/ERROR, never DEBUG
    
    def emit(self, record: logging.LogRecord):
        """
        Emit log record to in-memory buffer ONLY if it matches approved patterns.
        
        Args:
            record: Log record
        """
        # Never show DEBUG messages
        if record.levelno < logging.INFO:
            return
        
        try:
            message = self.format(record)
            
            # Check if message matches excluded patterns (explicitly block spam)
            for pattern in self.excluded_regex:
                if pattern.search(message):
                    return  # Excluded - don't show in UI
            
            # Check if message matches approved patterns (high-signal only)
            is_approved = False
            for pattern in self.approved_regex:
                if pattern.search(message):
                    is_approved = True
                    break
            
            # Also allow all ERROR/CRITICAL messages (always important)
            if record.levelno >= logging.ERROR:
                is_approved = True
            
            # Only add to buffer if approved
            if is_approved:
                timestamp = datetime.fromtimestamp(record.created)
                level = record.levelname
                self.buffer.append(timestamp, level, message)
        except Exception:
            # Silently fail to prevent logging loops
            pass


class InMemoryHandler(logging.Handler):
    """
    DEPRECATED: Legacy in-memory handler (replaced by UILogHandler).
    Kept for backward compatibility.
    """
    
    def __init__(self, buffer: InMemoryLogBuffer):
        super().__init__()
        self.buffer = buffer
    
    def emit(self, record: logging.LogRecord):
        try:
            timestamp = datetime.fromtimestamp(record.created)
            level = record.levelname
            message = self.format(record)
            self.buffer.append(timestamp, level, message)
        except Exception:
            pass


class StructuredLogger:
    """
    Structured logger with file and optional in-memory output.
    NO console output to prevent interference with Rich UI.
    """
    
    def __init__(
        self,
        name: str = "ScalperBot",
        log_dir: str = "logs",
        log_file: str = "bot.log",
        level: int = logging.INFO,
        file_level: int = logging.DEBUG,
        enable_console: bool = False,  # DISABLED by default for UI safety
        in_memory_buffer: Optional[InMemoryLogBuffer] = None
    ):
        """
        Initialize structured logger.
        
        Args:
            name: Logger name
            log_dir: Directory for log files
            log_file: Log file name
            level: Overall log level
            file_level: File log level
            enable_console: Enable console output (DANGEROUS with Rich UI)
            in_memory_buffer: Optional in-memory buffer for UI display
        """
        self.name = name
        self.log_dir = Path(log_dir)
        self.log_dir.mkdir(exist_ok=True)
        
        # Create logger
        self.logger = logging.getLogger(name)
        self.logger.setLevel(level)
        self.logger.handlers.clear()  # Remove any existing handlers
        
        # Prevent duplicate logs
        self.logger.propagate = False
        
        # ROTATING FILE HANDLER (primary output)
        log_path = self.log_dir / log_file
        max_bytes = int(os.getenv("LOG_MAX_BYTES", "10485760"))  # 10MB default
        backup_count = int(os.getenv("LOG_BACKUP_COUNT", "5"))  # Keep 5 backups
        
        file_handler = RotatingFileHandler(
            log_path,
            encoding='utf-8',
            maxBytes=max_bytes,
            backupCount=backup_count,
            mode='a'  # Append mode for rotation
        )
        file_handler.setLevel(file_level)
        file_formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(funcName)s:%(lineno)d - %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        file_handler.setFormatter(file_formatter)
        self.logger.addHandler(file_handler)
        
        # UI LOG HANDLER (for LOG panel display - FILTERED, high-signal only)
        if in_memory_buffer:
            ui_handler = UILogHandler(in_memory_buffer)
            ui_handler.setLevel(logging.INFO)  # Only INFO/WARNING/ERROR (no DEBUG)
            ui_formatter = logging.Formatter(
                '%(message)s',  # Just the message (no level prefix, already filtered)
                datefmt='%H:%M:%S'
            )
            ui_handler.setFormatter(ui_formatter)
            self.logger.addHandler(ui_handler)
        
        # CONSOLE HANDLER (DISABLED by default to prevent UI interference)
        # Only enable if explicitly requested (e.g., for debugging without UI)
        if enable_console:
            console_handler = logging.StreamHandler(sys.stdout)
            console_handler.setLevel(logging.INFO)
            console_formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            console_handler.setFormatter(console_formatter)
            self.logger.addHandler(console_handler)
        
        # Store log path for reference
        self.log_file_path = log_path
        self.in_memory_buffer = in_memory_buffer
    
    def debug(self, message: str, **context: Any):
        """Log debug message with optional context."""
        self._log(logging.DEBUG, message, **context)
    
    def info(self, message: str, **context: Any):
        """Log info message with optional context."""
        self._log(logging.INFO, message, **context)
    
    def warning(self, message: str, **context: Any):
        """Log warning message with optional context."""
        self._log(logging.WARNING, message, **context)
    
    def error(self, message: str, **context: Any):
        """Log error message with optional context."""
        self._log(logging.ERROR, message, **context)
    
    def critical(self, message: str, **context: Any):
        """Log critical message with optional context."""
        self._log(logging.CRITICAL, message, **context)
    
    def exception(self, message: str, **context: Any):
        """Log exception with traceback."""
        self._log(logging.ERROR, message, exc_info=True, **context)
    
    def isEnabledFor(self, level: int) -> bool:
        """
        Check if logging is enabled for the given level.
        OPTIMIZATION: Use this to avoid expensive message formatting when logging is disabled.
        
        Example:
            if logger.isEnabledFor(logging.DEBUG):
                logger.debug(f"Expensive computation: {expensive_function()}")
        
        Args:
            level: Log level to check (logging.DEBUG, logging.INFO, etc.)
            
        Returns:
            True if logging is enabled for this level
        """
        return self.logger.isEnabledFor(level)
    
    def _log(self, level: int, message: str, exc_info: bool = False, **context: Any):
        """
        Internal logging method with context support.
        
        Args:
            level: Log level
            message: Log message
            exc_info: Include exception info
            **context: Additional context fields
        """
        if context:
            # Format context as key=value pairs
            context_str = " | ".join(f"{k}={v}" for k, v in context.items())
            full_message = f"{message} | {context_str}"
        else:
            full_message = message
        
        self.logger.log(level, full_message, exc_info=exc_info)
    
    def log_trade(
        self,
        action: str,
        symbol: str,
        side: Optional[str] = None,
        price: Optional[float] = None,
        size: Optional[float] = None,
        pnl: Optional[float] = None,
        reason: Optional[str] = None,
        **extra: Any
    ):
        """
        Log trade-related event with structured data.
        
        Args:
            action: Trade action (entry, exit, partial_tp, etc.)
            symbol: Trading symbol
            side: Position side (long/short)
            price: Trade price
            size: Trade size
            pnl: Profit/loss
            reason: Reason for action
            **extra: Additional fields
        """
        context = {
            'action': action,
            'symbol': symbol,
            **extra
        }
        
        if side:
            context['side'] = side
        if price is not None:
            context['price'] = price
        if size is not None:
            context['size'] = size
        if pnl is not None:
            context['pnl'] = pnl
        if reason:
            context['reason'] = reason
        
        self.info(f"TRADE: {action.upper()}", **context)
    
    def log_signal(
        self,
        symbol: str,
        side: str,
        score: float,
        action: str,
        reason: Optional[str] = None,
        **extra: Any
    ):
        """
        Log signal decision with structured data.
        
        Args:
            symbol: Trading symbol
            side: Signal side (long/short)
            score: Signal score
            action: Action taken (approved/rejected)
            reason: Rejection reason if rejected
            **extra: Additional fields
        """
        context = {
            'symbol': symbol,
            'side': side,
            'score': score,
            'action': action,
            **extra
        }
        
        if reason:
            context['reason'] = reason
        
        self.info(f"SIGNAL: {action.upper()}", **context)
    
    def log_error_with_context(
        self,
        operation: str,
        error: Exception,
        symbol: Optional[str] = None,
        **context: Any
    ):
        """
        Log error with full context for debugging.
        
        Args:
            operation: Operation that failed
            error: Exception object
            symbol: Trading symbol if applicable
            **context: Additional context
        """
        error_context = {
            'operation': operation,
            'error_type': type(error).__name__,
            'error_message': str(error),
            **context
        }
        
        if symbol:
            error_context['symbol'] = symbol
        
        self.exception(f"ERROR in {operation}", **error_context)


# Global instances
_logger_instance: Optional[StructuredLogger] = None
_log_buffer: Optional[InMemoryLogBuffer] = None


def get_log_buffer() -> InMemoryLogBuffer:
    """
    Get or create global in-memory log buffer.
    Used by UI to display recent logs.
    
    Returns:
        InMemoryLogBuffer instance
    """
    global _log_buffer
    
    if _log_buffer is None:
        _log_buffer = InMemoryLogBuffer(maxlen=100)
    
    return _log_buffer


def get_logger(name: str = "ScalperBot", enable_console: bool = False) -> StructuredLogger:
    """
    Get or create global logger instance.
    Creates one log file per run with timestamped filename for easy analysis.
    
    Args:
        name: Logger name
        enable_console: Enable console output (default: False for UI safety)
        
    Returns:
        StructuredLogger instance
    """
    global _logger_instance
    
    if _logger_instance is None:
        # Determine log level from environment
        log_level_str = os.getenv("LOG_LEVEL", "INFO").upper()
        log_level_map = {
            "DEBUG": logging.DEBUG,
            "INFO": logging.INFO,
            "WARNING": logging.WARNING,
            "ERROR": logging.ERROR,
            "CRITICAL": logging.CRITICAL
        }
        log_level = log_level_map.get(log_level_str, logging.INFO)
        
        # Generate timestamped log filename: bot_YYYY-MM-DD_HH-MM-SS.log
        timestamp = datetime.now().strftime('%Y-%m-%d_%H-%M-%S')
        log_file = f"bot_{timestamp}.log"
        
        # Get global log buffer
        log_buffer = get_log_buffer()
        
        _logger_instance = StructuredLogger(
            name=name,
            log_file=log_file,
            level=log_level,
            file_level=logging.DEBUG,  # Always log everything to file
            enable_console=enable_console,  # Console disabled by default
            in_memory_buffer=log_buffer
        )
        
        # Log initialization (to file only)
        _logger_instance.info(f"Logger initialized | log_file={_logger_instance.log_file_path}")
    
    return _logger_instance


def disable_external_loggers():
    """
    Disable console output from external libraries (ccxt, httpx, etc.).
    Routes their logs to file only.
    """
    # Disable ccxt verbose logging
    logging.getLogger('ccxt').setLevel(logging.WARNING)
    logging.getLogger('ccxt').propagate = False
    
    # Disable httpx/httpcore verbose logging
    logging.getLogger('httpx').setLevel(logging.WARNING)
    logging.getLogger('httpcore').setLevel(logging.WARNING)
    
    # Disable urllib3 verbose logging
    logging.getLogger('urllib3').setLevel(logging.WARNING)
    
    # Remove all StreamHandlers from root logger
    root_logger = logging.getLogger()
    for handler in root_logger.handlers[:]:
        if isinstance(handler, logging.StreamHandler):
            root_logger.removeHandler(handler)
