"""
Symbol Scanner Module

RECOMMENDATION #7: Extracted scanner logic from bot.py for better modularity.

This module handles:
- Processing symbols for signal generation
- Fetching market data (tickers, orderbooks)
- Generating trading signals
- Scoring and filtering signals
"""

import asyncio
import time
from typing import Optional, Tuple, Dict, Any

from .logger import get_logger
from .config import (
    MIN_SIGNAL_SCORE, MIN_SIGNAL_STRENGTH,
    SIGNAL_PERCENTILE_THRESHOLD, DRY_RUN
)


class SymbolScanner:
    """Handles scanning symbols and generating signals."""
    
    def __init__(self, bot):
        """
        Initialize scanner with reference to bot.
        
        Args:
            bot: ScalperBot instance (for access to exchange, caches, etc.)
        """
        self.bot = bot
        self.logger = get_logger("SymbolScanner")
    
    async def process_symbol(
        self,
        symbol: str,
        batch_now: float,
        scan_regime_config: Dict,
        scan_recent_trades: list,
        scan_volatility_regime: str,
        scan_btc_trend: Optional[str]
    ) -> Tuple[str, ...]:
        """
        Process a single symbol: fetch data, generate signal, score it.
        
        PERFORMANCE OPTIMIZED:
        - Uses pre-bound invariants (regime_config, etc.)
        - Reuses batch timestamp
        - Cache-first for tickers and orderbooks
        
        Args:
            symbol: Symbol to process
            batch_now: Cached timestamp for this batch
            scan_regime_config: Pre-bound regime config
            scan_recent_trades: Pre-bound recent trades list
            scan_volatility_regime: Pre-bound volatility regime
            scan_btc_trend: Pre-bound BTC trend
        
        Returns:
            Tuple of (status, symbol, stats, signal, latency_ms, was_cache_hit, orderbook, orderbook_fetched)
        """
        try:
            symbol_now = batch_now  # Reuse batch timestamp
            
            # 1) Get denormalized symbol for exchange API
            denormalized_symbol = self.bot.exchange_wrapper.denormalize_symbol(symbol)
            
            # 2) Fetch ticker (cache-first)
            was_cache_hit = False
            try:
                stats = await asyncio.wait_for(
                    self.bot.ticker_cache.get_ticker_stats(
                        self.bot.exchange_wrapper, 
                        symbol,
                        denormalized_symbol
                    ),
                    timeout=1.5
                )
                was_cache_hit = self.bot.ticker_cache.is_cached(symbol)
            except asyncio.TimeoutError:
                return ('skipped', 'ticker_timeout', None, None, was_cache_hit, False)
            except Exception as e:
                self.logger.debug(f"Ticker fetch failed for {symbol}: {e}")
                return ('skipped', 'ticker_error', None, None, was_cache_hit, False)
            
            if stats is None:
                return ('skipped', 'no_stats', None, None, was_cache_hit, False)
            
            # PERFORMANCE: Pre-extract stats attributes to avoid repeated getattr() calls
            stats_pct_change = getattr(stats, 'pct_change_24h', None)
            stats_spread_bps = getattr(stats, 'spread_bps', None)
            stats_vol_quote = getattr(stats, 'vol_quote', None)
            stats_last = getattr(stats, 'last', None)
            stats_bid = getattr(stats, 'bid', None)
            stats_ask = getattr(stats, 'ask', None)
            
            # 3) Calculate latency
            latency_ms = (time.time() - symbol_now) * 1000.0
            
            # 4) Fetch orderbook (cache-first or fresh)
            orderbook = None
            orderbook_fetched = False
            
            # Try cache first
            cached_ob = self.bot.orderbook_cache.get(symbol)
            if cached_ob and (symbol_now - cached_ob.get('timestamp', 0)) < 5.0:
                orderbook = cached_ob['data']
                orderbook_fetched = True
            else:
                # Fetch fresh orderbook if not in cache or stale
                if not DRY_RUN and self.bot.budget.remaining() > 5:
                    try:
                        orderbook = await asyncio.wait_for(
                            self.bot.exchange_wrapper.fetch_order_book(denormalized_symbol, limit=20),
                            timeout=0.3
                        )
                        orderbook_fetched = True
                        self.bot.budget.tick(1, "orderbook")
                        
                        self.bot.orderbook_cache[symbol] = {
                            'data': orderbook,
                            'timestamp': symbol_now
                        }
                    except Exception:
                        orderbook = None
                        orderbook_fetched = False
            
            # 5) Generate signal
            signal = await self.bot.signal_generator.generate_signal(
                symbol=symbol,
                stats=stats,
                ohlcv=None,  # Will be fetched internally by signal generator
                orderbook=orderbook,
                regime_config=scan_regime_config,
                recent_trades=scan_recent_trades,
                volatility_regime=scan_volatility_regime,
                btc_trend=scan_btc_trend
            )
            
            # 6) Early filter: no signal
            if not signal:
                return ('skipped', 'no_signal', None, None, was_cache_hit, orderbook_fetched)
            
            # 7) Apply filters
            if signal.final_score < MIN_SIGNAL_SCORE:
                return ('skipped', 'low_score', None, None, was_cache_hit, orderbook_fetched)
            
            if signal.strength < MIN_SIGNAL_STRENGTH:
                return ('skipped', 'low_strength', None, None, was_cache_hit, orderbook_fetched)
            
            # 8) Percentile filter (if enabled)
            if SIGNAL_PERCENTILE_THRESHOLD > 0:
                # Check if signal is in top percentile
                # (This would need access to signal_generator's recent signals)
                pass
            
            return ('processed', symbol, stats, signal, latency_ms, was_cache_hit, orderbook, orderbook_fetched)
            
        except Exception as e:
            self.logger.debug(f"Error processing {symbol}: {e}")
            return ('error', symbol, None, None, False, False)

