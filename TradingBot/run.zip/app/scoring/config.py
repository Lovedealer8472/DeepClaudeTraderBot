"""Scoring Configuration - Hard caps and thresholds."""

from typing import Dict, Tuple

# Per-module hard caps (advisor mode: do not loosen these without thinking)
SCORE_CAPS: Dict[str, Tuple[float, float]] = {
    "liquidity":     (-10.0, 10.0),
    "regime":        (-10.0, 10.0),
    "structure":     (-20.0, 20.0),
    "portfolio":     (-15.0, 5.0),
    "time_of_day":   (-8.0, 8.0),
    "symbol_rating": (-10.0, 10.0),
}

# Global score bounds
SCORE_MIN = 0.0
SCORE_MAX = 100.0

# Base score now lives on the full 0–100 range.
# The primary scoring engine is trusted to output 0–100 directly.
# Modules add small adjustments (±5-20 points) around the base.
BASE_SCORE_MIN = 0.0
BASE_SCORE_MAX = 100.0

# Percentile + score thresholds for final filtering
MIN_SIGNAL_SCORE = 55.0        # minimum absolute score (lowered from 60 due to boosted scoring)
SIGNAL_PERCENTILE_THRESHOLD = 0.25  # e.g. top 25%

