"""Scoring Modules - Pure functions for each score dimension."""

from .context import SignalContext


def score_liquidity(ctx: SignalContext) -> float:
    """Compute liquidity score (uncapped). Centered at 0 for normal conditions."""
    s = 0.0

    # Spread - reward exceptional, penalize poor (most signals should get 0-2)
    if ctx.spread_pct <= 0.0002:      # <= 0.02% (exceptional)
        s += 3.0
    elif ctx.spread_pct <= 0.0005:    # <= 0.05% (good, typical for Binance)
        s += 1.0                      # Small reward, not +5
    elif ctx.spread_pct <= 0.0010:    # <= 0.10% (acceptable)
        s += 0.0                      # Neutral
    elif ctx.spread_pct <= 0.0020:    # <= 0.20% (mediocre)
        s -= 2.0
    else:
        s -= 5.0                      # Wide spread

    # Depth - reward exceptional, neutral for normal
    if ctx.depth_top_usd >= 50_000:   # Exceptional depth
        s += 4.0
    elif ctx.depth_top_usd >= 20_000: # Good depth
        s += 2.0
    elif ctx.depth_top_usd >= 5_000:  # Normal depth
        s += 0.0                      # Neutral
    elif ctx.depth_top_usd < 2_000:   # Thin
        s -= 3.0

    return s


def score_regime(ctx: SignalContext) -> float:
    """Compute volatility/regime score (uncapped). Centered at 0 for normal conditions."""
    atr = ctx.atr_pct
    adx = ctx.htf_adx
    s = 0.0

    # Most conditions should be neutral (0), only extreme conditions get adjustments
    if atr < 0.003 and adx < 12:
        # Very low-vol chop (rare, ideal for tight scalps)
        s += 3.0
    elif atr < 0.005 and adx < 15:
        # Low-vol (normal scalping)
        s += 1.0                     # Small bonus
    elif atr > 0.015 and adx > 30:
        # Strong trend (good for momentum)
        s += 2.0
    elif atr > 0.04:
        # Panic/extreme (dangerous)
        s -= 4.0
    else:
        # Normal conditions (most signals)
        s += 0.0

    return s


def score_structure(ctx: SignalContext) -> float:
    """Compute structure/pattern score (uncapped). Most signals get 0-5 points."""
    s = 0.0

    if ctx.side == "long":
        if ctx.htf_trend_dir == 1:
            s += 3.0                     # Reduced: basic trend alignment
        if ctx.at_range_low:
            s += 4.0                     # Range position matters
        if ctx.extreme_down:
            s += 6.0                     # Extreme readings are valuable
        if ctx.bullish_divergence:
            s += 5.0                     # Divergence is strong signal
        if ctx.exhaustion_down:
            s += 8.0                     # Exhaustion + reversal is rare
        if ctx.sfp_bottom:
            s += 10.0                    # SFP (stop hunt) is highest conviction
        if ctx.dist_from_vwap < -0.015:
            s += 3.0                     # VWAP distance bonus

    else:  # short
        if ctx.htf_trend_dir == -1:
            s += 3.0
        if ctx.at_range_high:
            s += 4.0
        if ctx.extreme_up:
            s += 6.0
        if ctx.bearish_divergence:
            s += 5.0
        if ctx.exhaustion_up:
            s += 8.0
        if ctx.sfp_top:
            s += 10.0
        if ctx.dist_from_vwap > 0.015:
            s += 3.0

    return s


def score_portfolio(ctx: SignalContext) -> float:
    """Compute portfolio/correlation score (uncapped)."""
    s = 0.0

    # Sector crowding
    if ctx.open_positions_same_sector >= 3:
        s -= 5.0                     # softened from -8.0
    elif ctx.open_positions_same_sector == 2:
        s -= 2.0                     # softened from -3.0

    # Correlation to BTC/ETH
    if ctx.corr_to_btc_24h > 0.9:
        s -= 3.0                     # softened from -5.0

    return s


def score_time_of_day(ctx: SignalContext) -> float:
    """Compute time-of-day score (uncapped). Centered at 0 for normal hours."""
    s = 0.0
    sess = ctx.session.upper()

    # Most trading hours should be neutral (0)
    # Only reward peak liquidity or penalize dead zones
    if sess == "US" and 14 <= ctx.hour_utc <= 20:
        # Peak US hours (9am-3pm EST) - highest liquidity overlap
        s += 2.0
    elif sess in ("EU", "US"):
        # Normal EU/US hours
        s += 0.0                     # Neutral, not +4
    elif sess == "ASIA":
        s += 0.0                     # Neutral, not +1

    if sess == "WEEKEND" and 0 <= ctx.hour_utc <= 6:
        # Dead weekend hours
        s -= 3.0

    return s


def score_symbol_rating(ctx: SignalContext) -> float:
    """Compute symbol rating score (uncapped)."""
    # ctx.symbol_rating is already in [-10,+10] by design, but we keep it as-is here.
    return ctx.symbol_rating

